// FILE: List.cpp
// CS 223 Winter 2018, Lab 4
//
// Student Name:
// Date:
//
// List class implementation for a circular doubly-linked list with sentinel
// node.
//
// Instance data:
//    Every List has a pointer (called "head_ptr") to its sentinel node.
//
// Class invariants:
//    1. All the list nodes, including the sentinel node, are stored in
//       dynamic memory.
//    2. The head pointer for the list ALWAYS points to the sentinel node.
//    3. The sentinel node's data is always the default value for
//       DLL_node::value_type.
//    4. For an EMPTY list, the sentinel node's links (prev, next) refer to
//       the sentinel node itself.
//
// NOTE 1: The DLL_node class is already completely implemented in DLL_node.h.
//
// NOTE 2: Use `DLL_node::value_type` to refer to the type of data stored in
//         a node.
//

#include <iostream>
#include <cassert>
#include <cstdlib>
#include <string>
#include "Person.h"
#include "DLL_node.h"
#include "List.h"

using namespace std;

namespace cs223_dll
{

// Private helper method. Use for diagnostics, to print out node info.
// Example use:
// cout << *head_ptr     -- Prints info on sentinel node
ostream& operator<<(ostream& out, const DLL_node& n)
{
    out << "Node at: " << &n << "\n"
        << "\tdata: " << n.data() << "\n"
        << "\tprev: " << n.prev() << "\n"
        << "\tnext: " << n.next() << endl;
    return out;
}

// setup_sentinel()
// private helper function for use by the constructors.
// Postcondition: head_ptr points to the sentinel node for an empty list


// default constructor
// Postcondition: the list has no items (just a sentinel node)


// copy constructor
// Postcondition: The new list is an independent copy of `other`.
//    Subsequent changes to one of the lists will *not* affect the
//    other list.


// Initializer list constructor, PROVIDED
// Creates a list with initial values provided by an initialization
// list. For example the declaration List L1({ A, B, C });
// creates a list with the three values in order.
List::List(std::initializer_list<DLL_node::value_type> l)
{
    setup_sentinel();
    for (auto it = l.begin(); it != l.end(); ++it)
    {
        tail_insert(*it);
    }
}

// destructor - test it indirectly by checking for memory leaks


// is_empty - checks if the list is empty
// Postcondition: Returns true iff there are no items in the list.


// front - get the value at the front of the list
// Precondition: This list is not empty.
// Postcondition: Return value is a copy of the value stored at
//    the front of the list.


// back - get the value at the end of the list
// Precondition: This list is not empty.
// Postcondition: Return value is a copy of the value stored at
//    the back of the list.


// contains - checks for an item in the list
// Postcondition: Returns true iff there is an item equivalent to
//    `val` in this list.


// Implement the bracket-indexing operator as a member function, operator[]
// Precondition:  i >= 0
// Precondition:  the list has at least i+1 items
// Postcondition: returns the ith item in the list, where indexing begins
//    with 0
// EXAMPLE: If myList is <D, O, G>, then myList[0] returns 'D',
//    myList[1] returns 'O', and myList[2] returns 'G'.


// head_insert - add an item to the front of the list
// Postcondition: The list has one more node than before, and the
//    value `val` is stored at the front of the list.
// EXAMPLE: If the list had items:  <r, o, n, t>, and then the call was
//    to head_insert('f'), the list now has items: <f, r, o, n, t>


// tail_insert - add an item to the end of the list
// Postcondition: The list has one more node than before, and the
//    value `val` is stored at the end of the list.
// EXAMPLE: If the list had items:  <p, i, g>, and then the call was
//    to tail_insert('g'), the list now has items: <p, i, g, g>


// head_remove - remove an item from the front of the list
// Postcondition:  Return value is `true` iff an item was removed.
//    If the list was empty before head_remove(), return value is
//    `false`.
// EXAMPLE:  If the list had items <f, r, o, g> before the call to
//    head_remove(), after the call the list has: <r, o, g>


// tail_remove - remove an item from the end of the list
// Postcondition:  Return value is `true` iff an item was removed.
//    If the list was empty before tail_remove(), return value is
//    `false`.
// EXAMPLE:  If the list had items <c, a, t, s> before the call to
//    tail_remove(), after the call the list has: <c, a, t>


// remove_first_of - tries to remove the first instance of an item
//    from the list
// Postcondition: Removes the front-most item in the list that is
//    equivalent (==) to the given value `val`.  Return value is
//    true iff an item was removed from the list.
// NOTE: If no item in the list is equivalent to `val`, the list
//    is unchanged and `false` is returned.
// EXAMPLE: The list has items: <2, 9, 2>.  A call to
//    remove_first_of('2') will return true, and the list items
//    are now: <9, 2>


// clear - deletes all items from the list
// Postcondition: List is empty.


// assignment operator
// Postcondition: This list becomes an identical -- but indepedent --
//    copy of `other` list.
// NOTE: Returns the updated list to enable chaining of assignment.


// list equivalence operator - implementation provided
// Postcondition: returns true when list1 and list2 have the same length
//   and store equivalent elements in the same order: for every position
//   i in the range [0, length of list1), the ith element of list1 is
//   equivalent to the ith element of list2
bool operator==(const List& list1, const List& list2)
{
    const DLL_node* head1 = list1.get_head_ptr();
    const DLL_node* head2 = list2.get_head_ptr();
    const DLL_node* curr1 = head1;
    const DLL_node* curr2 = head2;

    while (curr1->next() != head1 && curr2->next() != head2)
    {
        curr1 = curr1->next();
        curr2 = curr2->next();
        if (curr1->data() != curr2->data())
            return false;
    }

    return (curr1->next() == head1 && curr2->next() == head2);
}

// stream output operator - implementation provided
// Postcondition: For lists with length > 0, contents of the list are placed
//    into the given output stream using the following format:
//         "List:\n first_item\n ... \n last_item\n"
//    For lists of length = 0, the following will be placed into the
//    given output stream:
//         "Empty List\n"
//    EXAMPLE: If myList is <rain, grass, flowers>, then cout << myList will
//       produce the following in standard out:
//    List:
//     rain
//     grass
//     flowers
std::ostream& operator<<(std::ostream& out, const List& list)
{
    if (list.is_empty())
    {
        out << "Empty List" << endl;
    }
    else
    {
        out << "List:\n";
        const DLL_node* curr = list.get_head_ptr()->next();
        while (curr != list.get_head_ptr())
        {
            out << curr->data() << endl;
            curr = curr->next();
        }
    }
    return out;
}

}  // namespace cs223_dll
